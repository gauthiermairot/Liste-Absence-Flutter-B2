class Eleves {
  final String nom;
  final String email;
  final String image;
  bool absent;
  bool retard;
  Eleves(this.nom, this.email, this.image, this.absent, this.retard);
}
